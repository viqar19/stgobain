#!/bin/sh
git config push.default current
git config user.name "harshdeep-kalra"
git config user.email "harshdeep.kalra@in.ibm.com"
echo "config done"
git add $1
echo "added files"
git commit -m "Output$(date +%Y%m%di%H%M%S)" $1
echo "Files commited"
git status
git push
echo "files pushed"
