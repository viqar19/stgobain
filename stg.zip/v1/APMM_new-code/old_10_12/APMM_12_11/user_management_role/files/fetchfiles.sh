#!/bin/sh
git init
git fetch
git checkout origin/master -- requests.csv
#foldername=output$(date +%Y%m%di%H%M%S)
#foldername=output
#filename=output.csv
#filename=output$(date +%Y%m%di%H%M%S).csv
#mkdir -p $foldername
#touch $foldername/$filename
#chmod -R 777 ../apm_iam_reports
