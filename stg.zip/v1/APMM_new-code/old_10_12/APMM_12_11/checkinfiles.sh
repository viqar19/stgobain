#!/bin/sh
git add $1
git commit -m "Output$(date +%Y%m%di%H%M%S)" $1
git status
git push
